const state = {
    batchQueue: [],
    batchResults: [],
    currentResultIndex: 0,
    isProcessingBatch: false,
    totalBatchSize: 0,
};

const API = '';

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initUploadArea();
});

function initUploadArea() {
    const area = document.getElementById('upload-area');
    if (!area) return;

    area.addEventListener('dragover', (e) => {
        e.preventDefault();
        area.classList.add('dragover');
    });

    area.addEventListener('dragleave', () => {
        area.classList.remove('dragover');
    });

    area.addEventListener('drop', async (e) => {
        e.preventDefault();
        area.classList.remove('dragover');
        
        const files = await extractAllFiles(e.dataTransfer);
        const imageFiles = files.filter(f => f.type.startsWith('image/'));
        
        if (imageFiles.length > 0) {
            enqueueFiles(imageFiles);
        } else {
            showToast('Aucune image trouvée', 'error');
        }
    });
}

function handleFileUpload(event) {
    const files = Array.from(event.target.files);
    const imageFiles = files.filter(f => f.type.startsWith('image/'));
    
    if (imageFiles.length > 0) {
        enqueueFiles(imageFiles);
    }
}

async function extractAllFiles(dataTransfer) {
    const files = [];
    if (dataTransfer.items) {
        const promises = [];
        for (let i = 0; i < dataTransfer.items.length; i++) {
            const item = dataTransfer.items[i];
            if (item.kind === 'file') {
                const entry = item.webkitGetAsEntry ? item.webkitGetAsEntry() : null;
                if (entry) {
                    promises.push(traverseFileTree(entry, files));
                } else {
                    files.push(item.getAsFile());
                }
            }
        }
        await Promise.all(promises);
    } else {
        for (let i = 0; i < dataTransfer.files.length; i++) {
            files.push(dataTransfer.files[i]);
        }
    }
    return files;
}

function traverseFileTree(item, files) {
    return new Promise((resolve) => {
        if (item.isFile) {
            item.file((file) => {
                files.push(file);
                resolve();
            });
        } else if (item.isDirectory) {
            const dirReader = item.createReader();
            dirReader.readEntries(async (entries) => {
                const promises = entries.map(e => traverseFileTree(e, files));
                await Promise.all(promises);
                resolve();
            });
        } else {
            resolve();
        }
    });
}

function enqueueFiles(files) {
    state.batchQueue.push(...files);
    if (!state.isProcessingBatch) {
        state.batchResults = [];
        state.currentResultIndex = 0;
        state.totalBatchSize = state.batchQueue.length;
        processBatchQueue();
    } else {
        state.totalBatchSize += files.length;
        updateBatchProgressUI();
    }
}

async function processBatchQueue() {
    state.isProcessingBatch = true;
    
    const progressContainer = document.getElementById('batch-progress-container');
    if (progressContainer) progressContainer.style.display = 'block';

    while (state.batchQueue.length > 0) {
        const file = state.batchQueue.shift();
        updateBatchProgressUI(file.name);
        
        try {
            await processSingleUpload(file);
        } catch (e) {
            console.error(`Erreur sur l'image ${file.name}`, e);
        }
    }
    
    state.isProcessingBatch = false;
    updateBatchProgressUI('Terminé', true);
    
    setTimeout(() => {
        if (progressContainer) progressContainer.style.display = 'none';
        const fileInput = document.getElementById('file-input');
        if (fileInput) fileInput.value = '';
    }, 3000);
}

function updateBatchProgressUI(currentFileName = '', finished = false) {
    const progressContainer = document.getElementById('batch-progress-container');
    const statusText = document.getElementById('batch-status-text');
    const countText = document.getElementById('batch-count-text');
    const progressBar = document.getElementById('batch-progress-bar');
    
    if (!progressContainer) return;
    
    const total = state.totalBatchSize;
    const processed = total - state.batchQueue.length - (finished ? 0 : 1);
    const progressPct = total > 0 ? ((processed / total) * 100) : 0;
    
    if (finished) {
        statusText.textContent = `✅ Batch terminé (${total} images)`;
        countText.textContent = `${total} / ${total}`;
        progressBar.style.width = `100%`;
        progressBar.style.background = '#22c55e';
    } else {
        statusText.textContent = `Analyse en cours : ${currentFileName}`;
        countText.textContent = `${processed + 1} / ${total}`;
        progressBar.style.width = `${progressPct}%`;
        progressBar.style.background = 'var(--accent-primary)';
    }
}

async function processSingleUpload(file) {
    const analysisPanel = document.getElementById('analysis-results');
    const analysisContent = document.getElementById('analysis-content');
    analysisPanel.style.display = 'block';
    
    const imagePreviewUrl = URL.createObjectURL(file);
    
    analysisContent.innerHTML = `
        <div style="display:flex;gap:1.5rem;align-items:flex-start;flex-wrap:wrap;">
            <div style="flex:0 0 200px;">
                <img src="${imagePreviewUrl}" alt="Image analysée" 
                     style="width:200px;height:200px;object-fit:cover;border-radius:8px;border:2px solid var(--border-color);">
                <div style="text-align:center;margin-top:0.5rem;font-size:0.75rem;color:var(--text-muted);">${file.name}</div>
            </div>
            <div style="flex:1;min-width:250px;">
                <div style="display:flex;align-items:center;gap:0.5rem;margin-bottom:1rem;">
                    <div class="loading-spinner"></div>
                    <span style="color:var(--accent-primary);font-weight:600;">Analyse en cours...</span>
                </div>
                <div style="font-size:0.85rem;color:var(--text-muted);">
                    <p>⚙️ Étape 1/3 : Détection YOLOv8 des navires...</p>
                    <p>⚙️ Étape 2/3 : Classification militaire / civil...</p>
                    <p>⚙️ Étape 3/3 : Analyse Mistral AI (si activée)...</p>
                </div>
            </div>
        </div>
    `;
    analysisPanel.scrollIntoView({ behavior: 'smooth' });

    const formData = new FormData();
    formData.append('file', file);

    const zone = document.getElementById('input-zone')?.value || 'Zone inconnue';
    const risk = document.getElementById('input-risk')?.value || 'Medium';
    const confidence = document.getElementById('input-confidence')?.value || 0.25;
    const useMistral = document.getElementById('input-mistral')?.checked || false;

    const params = new URLSearchParams({
        zone_name: zone,
        lat: 0,
        lon: 0,
        risk_level: risk,
        confidence: confidence,
        use_mistral: useMistral,
    });

    try {
        const resp = await fetch(`${API}/api/detect?${params}`, {
            method: 'POST',
            body: formData,
        });

        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();

        const numDet = data.detections?.length || 0;
        const numMil = data.detections?.filter(d => d.is_military).length || 0;

        state.batchResults.push({
            data: data,
            filename: file.name,
            imageUrl: imagePreviewUrl,
            mistralUsed: useMistral
        });
        
        state.currentResultIndex = state.batchResults.length - 1;
        renderAnalysisPage(state.currentResultIndex);

        showToast(`✅ ${numDet} navire(s) détecté(s) dont ${numMil} militaire(s)`, numMil > 0 ? 'error' : 'success');
    } catch (err) {
        state.batchResults.push({
            error: true,
            message: err.message,
            filename: file.name,
            imageUrl: imagePreviewUrl
        });
        state.currentResultIndex = state.batchResults.length - 1;
        renderAnalysisPage(state.currentResultIndex);
        
        showToast(`❌ Erreur sur ${file.name}: ${err.message}`, 'error');
        console.error('Upload error:', err);
    }
}

function prevAnalysis() {
    if (state.currentResultIndex > 0) {
        state.currentResultIndex--;
        renderAnalysisPage(state.currentResultIndex);
    }
}

function nextAnalysis() {
    if (state.currentResultIndex < state.batchResults.length - 1) {
        state.currentResultIndex++;
        renderAnalysisPage(state.currentResultIndex);
    }
}

function renderAnalysisPage(index) {
    const paginationContainer = document.getElementById('analysis-pagination');
    const pageText = document.getElementById('analysis-page-text');
    const btnPrev = document.getElementById('btn-prev-analysis');
    const btnNext = document.getElementById('btn-next-analysis');
    
    if (state.batchResults.length <= 1) {
        if (paginationContainer) paginationContainer.style.display = 'none';
    } else {
        if (paginationContainer) paginationContainer.style.display = 'flex';
        if (pageText) pageText.textContent = `${index + 1} / ${state.batchResults.length}`;
        if (btnPrev) btnPrev.disabled = index === 0;
        if (btnNext) btnNext.disabled = index === state.batchResults.length - 1;
    }
    
    const result = state.batchResults[index];
    if (!result) return;
    
    if (result.error) {
        const content = document.getElementById('analysis-content');
        content.innerHTML = `
            <div style="display:flex;gap:1.5rem;align-items:flex-start;flex-wrap:wrap;">
                <div style="flex:0 0 200px;">
                    <img src="${result.imageUrl}" style="width:200px;height:200px;object-fit:cover;border-radius:8px;border:2px solid var(--border-color);">
                    <div style="text-align:center;margin-top:0.5rem;font-size:0.75rem;color:var(--text-muted);">${result.filename}</div>
                </div>
                <div style="padding:2rem;text-align:center;flex:1;">
                    <div style="font-size:2rem;margin-bottom:1rem;">❌</div>
                    <div style="font-size:1.1rem;font-weight:600;color:#ef4444;">Erreur lors de l'analyse</div>
                    <div style="color:var(--text-muted);margin-top:0.5rem;">${result.message}</div>
                </div>
            </div>
        `;
    } else {
        showAnalysisResults(result.data, result.filename, result.imageUrl, result.mistralUsed);
    }
}

function showAnalysisResults(data, filename, imageUrl, mistralUsed) {
    const content = document.getElementById('analysis-content');
    const detections = data.detections || [];
    const numDet = detections.length;
    const numMil = detections.filter(d => d.is_military).length;
    const numCiv = numDet - numMil;

    let mistralHTML = '';
    for (const det of detections) {
        if (det.mistral_analysis) {
            mistralHTML += `
                <div style="margin-top:1rem;padding:1rem;background:rgba(168,85,247,0.1);
                     border-left:3px solid #a855f7;border-radius:6px;">
                    <div style="font-weight:600;color:#a855f7;margin-bottom:0.5rem;">🤖 Analyse Mistral AI</div>
                    <div style="font-size:0.85rem;color:var(--text-secondary);line-height:1.6;">
                        ${det.mistral_analysis.replace(/\n/g, '<br>')}
                    </div>
                </div>
            `;
        }
    }

    let detectionsHTML = '';
    for (const det of detections) {
        const isMil = det.is_military;
        const badgeColor = isMil ? '#ef4444' : '#22c55e';
        const badgeText = isMil ? '⚔️ MILITAIRE' : '🚢 CIVIL';
        const category = det.category || det.ship_type || 'Inconnu';
        const quadrant = det.quadrant || 'N/A';
        const conf = Math.round((det.confidence || 0) * 100);

        detectionsHTML += `
            <div style="display:flex;align-items:center;gap:0.75rem;padding:0.5rem;
                 background:var(--surface-secondary);border-radius:6px;margin-bottom:0.5rem;">
                ${det.crop_b64 ? 
                    `<img src="data:image/jpeg;base64,${det.crop_b64}" 
                          style="width:60px;height:60px;object-fit:cover;border-radius:4px;">` : 
                    `<div style="width:60px;height:60px;display:flex;align-items:center;
                          justify-content:center;background:var(--surface-tertiary);
                          border-radius:4px;font-size:1.5rem;">${isMil ? '⚔️' : '🚢'}</div>`
                }
                <div style="flex:1;">
                    <div style="font-weight:600;color:var(--text-primary);">${category}</div>
                    <div style="display:flex;gap:0.5rem;margin-top:0.25rem;flex-wrap:wrap;">
                        <span style="font-size:0.7rem;padding:2px 6px;border-radius:4px;
                              background:${badgeColor};color:white;font-weight:600;">${badgeText}</span>
                        <span style="font-size:0.7rem;color:var(--text-muted);">🧭 ${quadrant}</span>
                        <span style="font-size:0.7rem;color:var(--text-muted);">📊 ${conf}%</span>
                    </div>
                </div>
            </div>
        `;
    }

    content.innerHTML = `
        <div style="display:flex;gap:1.5rem;align-items:flex-start;flex-wrap:wrap;">
            <div style="flex:0 0 200px;">
                <img src="${imageUrl}" alt="Image analysée" 
                     style="width:200px;height:200px;object-fit:cover;border-radius:8px;
                            border:2px solid var(--border-color);">
                <div style="text-align:center;margin-top:0.5rem;font-size:0.75rem;
                     color:var(--text-muted);">${filename}</div>
            </div>
            <div style="flex:1;min-width:280px;">
                <div style="display:flex;gap:0.75rem;margin-bottom:1rem;flex-wrap:wrap;">
                    <div style="padding:0.5rem 1rem;border-radius:8px;background:var(--surface-secondary);text-align:center;">
                        <div style="font-size:1.5rem;font-weight:700;color:var(--accent-primary);">${numDet}</div>
                        <div style="font-size:0.7rem;color:var(--text-muted);">Détection(s)</div>
                    </div>
                    <div style="padding:0.5rem 1rem;border-radius:8px;background:var(--surface-secondary);text-align:center;">
                        <div style="font-size:1.5rem;font-weight:700;color:#ef4444;">${numMil}</div>
                        <div style="font-size:0.7rem;color:var(--text-muted);">Militaire(s)</div>
                    </div>
                    <div style="padding:0.5rem 1rem;border-radius:8px;background:var(--surface-secondary);text-align:center;">
                        <div style="font-size:1.5rem;font-weight:700;color:#22c55e;">${numCiv}</div>
                        <div style="font-size:0.7rem;color:var(--text-muted);">Civil(s)</div>
                    </div>
                    <div style="padding:0.5rem 1rem;border-radius:8px;background:var(--surface-secondary);text-align:center;">
                        <div style="font-size:1.5rem;font-weight:700;color:var(--text-secondary);">
                            ${mistralUsed ? '✅' : '⏭️'}
                        </div>
                        <div style="font-size:0.7rem;color:var(--text-muted);">Mistral AI</div>
                    </div>
                </div>

                <div style="padding:0.75rem;background:var(--surface-secondary);border-radius:6px;
                     margin-bottom:0.75rem;font-size:0.85rem;">
                    ${numDet > 0 
                        ? `<span style="color:#22c55e;">✅ YOLOv8 a détecté ${numDet} objet(s) dans l'image.</span>` 
                        : `<span style="color:#f59e0b;">⚠️ YOLOv8 n'a détecté aucun navire avec le modèle standard. 
                           ${mistralUsed ? 'Analyse Mistral AI envoyée en compensation.' : 'Activez Mistral AI pour une analyse approfondie.'}</span>`
                    }
                </div>

                ${detectionsHTML}
                ${mistralHTML || (mistralUsed ? '<div style="color:var(--text-muted);font-size:0.85rem;margin-top:0.5rem;">Mistral AI n\'a pas retourné d\'analyse pour cette image.</div>' : '')}
            </div>
        </div>
    `;
}

function closeAnalysis() {
    const panel = document.getElementById('analysis-results');
    if (panel) panel.style.display = 'none';
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.innerHTML = `<span>${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

function initTheme() {
    const saved = localStorage.getItem('navalhunter-theme') || 'dark';
    applyTheme(saved);
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'light' ? 'dark' : 'light';
    applyTheme(next);
    localStorage.setItem('navalhunter-theme', next);
    showToast(next === 'light' ? 'Mode clair activé' : 'Mode sombre activé', 'info');
}

function applyTheme(theme) {
    if (theme === 'light') {
        document.documentElement.setAttribute('data-theme', 'light');
    } else {
        document.documentElement.removeAttribute('data-theme');
    }
    const btn = document.getElementById('btn-theme');
    if (btn) {
        btn.textContent = theme === 'light' ? '☀️' : '🌙';
    }
}
