﻿import os
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
from services.pipeline import detection_pipeline

app = FastAPI(title="NavalHunter Standalone Analysis API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Servir les fichiers statiques du frontend
frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

@app.get("/", response_class=HTMLResponse)
async def get_index():
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            return f.read()
    return "<html><body><h1>Interface introuvable</h1></body></html>"

@app.post("/api/detect")
async def detect_ships(
    file: UploadFile = File(...),
    zone_name: str = Form("Zone inconnue"),
    lat: float = Form(0.0),
    lon: float = Form(0.0),
    risk_level: str = Form("Medium"),
    confidence: float = Form(0.25),
    use_mistral: bool = Form(False)
):
    try:
        content = await file.read()
        res = detection_pipeline.process_image(
            image_bytes=content,
            filename=file.filename,
            zone_name=zone_name,
            lat=lat,
            lon=lon,
            risk_level=risk_level,
            min_confidence=confidence,
            use_mistral=use_mistral
        )
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("app:app", host="127.0.0.1", port=8080, reload=True)
