"""
NavalHunter — Configuration centrale
Chargement des variables d'environnement et paramètres globaux.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Chargement du .env
load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# ============================================================
# Chemins
# ============================================================
PROJECT_ROOT = Path(__file__).resolve().parent.parent
BACKEND_DIR = PROJECT_ROOT / "backend"
FRONTEND_DIR = PROJECT_ROOT / "frontend"
DATA_DIR = PROJECT_ROOT / "data"
HACKATHON_DIR = DATA_DIR / "hackathon"
MODELS_DIR = DATA_DIR / "models"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"
REPORTS_DIR = OUTPUTS_DIR / "reports"
DETECTIONS_DIR = OUTPUTS_DIR / "detections"

# Créer les répertoires s'ils n'existent pas
for d in [HACKATHON_DIR, MODELS_DIR, OUTPUTS_DIR, REPORTS_DIR, DETECTIONS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ============================================================
# Chemin vers les données du Hackathon (originales)
# ============================================================
SUJET5_ROOT = PROJECT_ROOT.parent.parent / "SujetsHackathon2026" / "Sujet5"
MISE_EN_JAMBE_DIR = SUJET5_ROOT / "MiseEnJambe"
GENERALISATION_DIR = SUJET5_ROOT / "Généralisation"

# ============================================================
# API Mistral
# ============================================================
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "")
MISTRAL_MODEL = "mistral-small-latest"

# ============================================================
# Paramètres de détection YOLOv8
# ============================================================
YOLO_MODEL_NAME = "yolov8n.pt"  # Modèle de base (nano), rapide même en CPU
YOLO_CONFIDENCE_THRESHOLD = 0.25
YOLO_IOU_THRESHOLD = 0.45
YOLO_SHIP_CLASSES = [8]  # Classe "boat" dans COCO = id 8

# ============================================================
# Catégories de navires (format hackathon)
# ============================================================
SHIP_CATEGORIES = {
    1: {"name": "Navire civil", "military": False, "color": "#4CAF50"},
    2: {"name": "Navire de guerre", "military": True, "color": "#F44336"},
    3: {"name": "Frégate", "military": True, "color": "#E91E63"},
    4: {"name": "Destroyer", "military": True, "color": "#9C27B0"},
    5: {"name": "Porte-avions", "military": True, "color": "#FF5722"},
    6: {"name": "Pétrolier", "military": False, "color": "#2196F3"},
    7: {"name": "Cargo", "military": False, "color": "#00BCD4"},
    8: {"name": "Chalutier", "military": False, "color": "#8BC34A"},
    9: {"name": "Sous-marin", "military": True, "color": "#795548"},
    10: {"name": "Croiseur", "military": True, "color": "#FF9800"},
    11: {"name": "Corvette", "military": True, "color": "#673AB7"},
    12: {"name": "Navire de soutien", "military": False, "color": "#607D8B"},
    13: {"name": "Bâtiment de débarquement", "military": False, "color": "#009688"},
}

# Types militaires pour la classification
MILITARY_TYPES = [k for k, v in SHIP_CATEGORIES.items() if v["military"]]
CIVIL_TYPES = [k for k, v in SHIP_CATEGORIES.items() if not v["military"]]

# ============================================================
# Serveur
# ============================================================
HOST = "127.0.0.1"
PORT = 8000
