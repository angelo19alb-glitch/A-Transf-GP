"""
NavalHunter — Pipeline complet de détection et classification
Orchestre : Détection YOLOv8 → Classification → Analyse Mistral → Rapport
"""
import io
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

from PIL import Image

from backend.config import DETECTIONS_DIR, SHIP_CATEGORIES
from backend.models.detector import ship_detector
from backend.models.classifier import ship_classifier
from backend.models.analyzer import mistral_analyzer


class DetectionPipeline:
    """Pipeline complet : image → détections classifiées → rapport."""

    def __init__(self):
        self.detections_history: list[dict] = []

    def process_image(
        self,
        image_bytes: bytes,
        filename: str = "upload.jpg",
        zone_name: str = "Zone inconnue",
        coordinates: tuple = (0.0, 0.0),
        risk_level: str = "Medium",
        confidence_threshold: float = 0.25,
        use_mistral: bool = False,
    ) -> dict:
        """
        Pipeline complet sur une image.

        Returns:
            {
                "image_id": str,
                "filename": str,
                "timestamp": str,
                "detections": [...],
                "summary": {...},
                "report": str (si use_mistral)
            }
        """
        image_id = f"IMG-{uuid.uuid4().hex[:8].upper()}"
        timestamp = datetime.now().isoformat()
        print(f"[Pipeline] === Nouvelle analyse : {filename} (id={image_id}) ===")
        print(f"[Pipeline] use_mistral={use_mistral}, zone={zone_name}, risk={risk_level}")

        # ─── Étape 1 : Détection YOLOv8 ───
        try:
            detections = ship_detector.detect_and_crop(
                image_bytes, confidence=confidence_threshold
            )
            print(f"[Pipeline] YOLO: {len(detections)} objet(s) détecté(s)")
        except Exception as e:
            print(f"[Pipeline] ERREUR détection YOLO: {e}")
            detections = []

        # ─── Étape 2 : Classification ───
        classified_detections = []
        for i, det in enumerate(detections):
            classification = ship_classifier.classify(det)
            classified_det = {
                "detection_id": f"DET-{image_id}-{i+1:04d}",
                "image_id": image_id,
                "filename": filename,
                "timestamp": timestamp,
                **det,
                **classification,
                "zone_name": zone_name,
                "coordinates": {"lat": coordinates[0], "lon": coordinates[1]},
                "risk_level": risk_level,
            }
            classified_detections.append(classified_det)
            print(f"[Pipeline] Classification #{i+1}: {classification.get('category', '?')} "
                  f"(militaire={classification.get('is_military', '?')}, "
                  f"quadrant={det.get('quadrant', '?')})")

        # ─── Étape 3 : Analyse Mistral (optionnelle) ───
        if use_mistral:
            print(f"[Pipeline] Mistral demandé. Disponible: {mistral_analyzer.available}")
            if mistral_analyzer.available:
                if len(classified_detections) > 0:
                    for det in classified_detections[:3]:
                        if "crop_b64" in det:
                            context = {
                                "zone_name": zone_name,
                                "risk_level": risk_level,
                                "confidence": det["confidence"],
                                "area_pct": det.get("area_pct", 0),
                            }
                            print(f"[Pipeline] Envoi crop à Mistral...")
                            det["mistral_analysis"] = mistral_analyzer.analyze_ship_crop(
                                det["crop_b64"], context
                            )
                            print(f"[Pipeline] Mistral a répondu (crop).")
                else:
                    # Fallback: YOLO n'a rien vu, on envoie l'image redimensionnée
                    print("[Pipeline] YOLO n'a rien trouvé. Envoi de l'image complète à Mistral...")
                    try:
                        import base64
                        # Redimensionner l'image pour éviter les timeouts API
                        pil_img = Image.open(io.BytesIO(image_bytes))
                        max_dim = 512
                        if pil_img.width > max_dim or pil_img.height > max_dim:
                            pil_img.thumbnail((max_dim, max_dim), Image.LANCZOS)
                        buf = io.BytesIO()
                        pil_img.save(buf, format="JPEG", quality=85)
                        resized_b64 = base64.b64encode(buf.getvalue()).decode('utf-8')
                        print(f"[Pipeline] Image redimensionnée: {pil_img.width}x{pil_img.height}, "
                              f"taille b64: {len(resized_b64)} chars")

                        context = {
                            "zone_name": zone_name,
                            "risk_level": risk_level,
                            "confidence": 0,
                            "area_pct": 100,
                        }
                        analysis = mistral_analyzer.analyze_ship_crop(resized_b64, context)
                        print(f"[Pipeline] Mistral a répondu (fallback). Longueur: {len(analysis)} chars")

                        # Thumbnail encore plus petit pour le frontend (preview)
                        pil_thumb = Image.open(io.BytesIO(image_bytes))
                        pil_thumb.thumbnail((256, 256), Image.LANCZOS)
                        buf2 = io.BytesIO()
                        pil_thumb.save(buf2, format="JPEG", quality=70)
                        thumb_b64 = base64.b64encode(buf2.getvalue()).decode('utf-8')

                        fallback_det = {
                            "detection_id": f"DET-{image_id}-MISTRAL",
                            "image_id": image_id,
                            "filename": filename,
                            "timestamp": timestamp,
                            "category": "Analyse Globale IA",
                            "confidence": 0.95,
                            "is_military": "militaire" in analysis.lower() or "guerre" in analysis.lower(),
                            "ship_type": "Analyse Visuelle Mistral",
                            "mistral_analysis": analysis,
                            "crop_b64": thumb_b64,
                            "zone_name": zone_name,
                            "coordinates": {"lat": coordinates[0], "lon": coordinates[1]},
                            "risk_level": risk_level,
                            "quadrant": "Image Entière",
                        }
                        classified_detections.append(fallback_det)
                        print(f"[Pipeline] Fallback Mistral ajouté avec succès.")
                    except Exception as e:
                        print(f"[Pipeline] ERREUR Mistral fallback: {e}")
            else:
                print("[Pipeline] Mistral NON disponible (clé API manquante ou erreur init).")
        else:
            print("[Pipeline] Mistral non demandé (case décochée).")

        # ─── Résumé ───
        military_count = sum(
            1 for d in classified_detections if d.get("is_military", False)
        )
        summary = {
            "image_id": image_id,
            "filename": filename,
            "timestamp": timestamp,
            "zone_name": zone_name,
            "risk_level": risk_level,
            "total_detections": len(classified_detections),
            "military_count": military_count,
            "civil_count": len(classified_detections) - military_count,
            "avg_confidence": (
                round(
                    sum(d["confidence"] for d in classified_detections)
                    / max(len(classified_detections), 1),
                    4,
                )
            ),
            "ship_types": {},
        }

        for det in classified_detections:
            st = det.get("ship_type", "Inconnu")
            summary["ship_types"][st] = summary["ship_types"].get(st, 0) + 1

        result = {
            "image_id": image_id,
            "filename": filename,
            "timestamp": timestamp,
            "detections": classified_detections,
            "summary": summary,
        }
        self.detections_history.append(result)
        self._save_result(result)

        print(f"[Pipeline] === Résultat: {len(classified_detections)} détection(s), "
              f"{military_count} militaire(s) ===")
        return result

    def get_global_stats(self) -> dict:
        """Statistiques globales sur toutes les détections effectuées."""
        all_detections = []
        for result in self.detections_history:
            all_detections.extend(result["detections"])

        if not all_detections:
            return {
                "total_images_processed": 0,
                "total_detections": 0,
                "military_count": 0,
                "civil_count": 0,
            }

        military_count = sum(1 for d in all_detections if d.get("is_military", False))

        types_count = {}
        zones_count = {}
        for det in all_detections:
            st = det.get("ship_type", "Inconnu")
            types_count[st] = types_count.get(st, 0) + 1
            zone = det.get("zone_name", "Inconnue")
            zones_count[zone] = zones_count.get(zone, 0) + 1

        return {
            "total_images_processed": len(self.detections_history),
            "total_detections": len(all_detections),
            "military_count": military_count,
            "civil_count": len(all_detections) - military_count,
            "avg_confidence": round(
                sum(d["confidence"] for d in all_detections) / len(all_detections), 4
            ),
            "by_type": types_count,
            "by_zone": zones_count,
        }

    def generate_report(self) -> str:
        """Génère un rapport complet de mission."""
        stats = self.get_global_stats()
        return mistral_analyzer.generate_mission_report(stats)

    def _save_result(self, result: dict):
        """Sauvegarde un résultat de détection en JSON."""
        filepath = DETECTIONS_DIR / f"{result['image_id']}.json"

        # Retirer les crops base64 pour réduire la taille du fichier
        save_data = json.loads(json.dumps(result, default=str))
        for det in save_data.get("detections", []):
            det.pop("crop_b64", None)

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(save_data, f, ensure_ascii=False, indent=2)


# Instance singleton
detection_pipeline = DetectionPipeline()
