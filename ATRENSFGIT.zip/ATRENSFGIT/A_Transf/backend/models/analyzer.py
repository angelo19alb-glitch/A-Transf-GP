"""
NavalHunter — Analyseur Mistral AI
Utilise l'API Mistral pour l'analyse enrichie des détections
et la génération de rapports de mission.
"""
import base64
import json
from datetime import datetime
from typing import Optional

from backend.config import MISTRAL_API_KEY, MISTRAL_MODEL


class MistralAnalyzer:
    """
    Interface avec l'API Mistral AI pour :
    - Analyse multimodale (vision) des crops de navires
    - Génération de rapports de mission
    - Corrélation géopolitique
    """

    def __init__(self):
        self._client = None

    @property
    def client(self):
        """Chargement paresseux du client Mistral."""
        if self._client is None:
            if not MISTRAL_API_KEY:
                print("[NavalHunter] ATTENTION: Clé API Mistral non configurée")
                return None
            try:
                from mistralai import Mistral
                self._client = Mistral(api_key=MISTRAL_API_KEY)
                print("[NavalHunter] Client Mistral AI initialisé")
            except ImportError:
                print("[NavalHunter] ERREUR: mistralai non installé. pip install mistralai")
                return None
        return self._client

    @property
    def available(self) -> bool:
        """Vérifie si l'API Mistral est disponible."""
        return self.client is not None

    def analyze_ship_crop(self, crop_b64: str, context: dict = None) -> str:
        """
        Analyse un crop de navire via la vision multimodale Mistral.

        Args:
            crop_b64: Image du navire en base64
            context: Infos supplémentaires (zone, confiance, etc.)

        Returns:
            Description textuelle du navire
        """
        if not self.available:
            return self._fallback_analysis(context)

        ctx_text = ""
        if context:
            ctx_text = f"""
Contexte de détection :
- Zone : {context.get('zone_name', 'Inconnue')}
- Niveau de risque : {context.get('risk_level', 'Inconnu')}
- Confiance détection : {context.get('confidence', 'N/A')}
- Taille relative : {context.get('area_pct', 'N/A')}%
"""

        try:
            response = self.client.chat.complete(
                model=MISTRAL_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Tu es un analyste naval expert en identification de navires "
                            "sur images satellites. Tu travailles pour un centre d'analyse "
                            "de renseignement. Sois précis, factuel et concis. "
                            "Réponds en français."
                        ),
                    },
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": (
                                    f"Analyse ce crop d'image satellite montrant un navire. "
                                    f"Identifie le type probable du navire (militaire/civil), "
                                    f"sa classe si possible, et tout détail pertinent.\n{ctx_text}"
                                ),
                            },
                            {
                                "type": "image_url",
                                "image_url": f"data:image/png;base64,{crop_b64}",
                            },
                        ],
                    },
                ],
                max_tokens=500,
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"[NavalHunter] Erreur Mistral vision: {e}")
            return self._fallback_analysis(context)

    def generate_mission_report(self, detections_summary: dict) -> str:
        """
        Génère un rapport de mission complet à partir des résultats de détection.

        Args:
            detections_summary: Statistiques et résumé des détections

        Returns:
            Rapport formaté en markdown
        """
        if not self.available:
            return self._generate_fallback_report(detections_summary)

        summary_json = json.dumps(detections_summary, ensure_ascii=False, indent=2)
        now = datetime.now().strftime("%d/%m/%Y à %H:%M")

        try:
            response = self.client.chat.complete(
                model=MISTRAL_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Tu es un analyste naval senior du Ministère des Armées. "
                            "Tu rédiges des rapports de mission clairs, structurés et "
                            "professionnels en français. Utilise le format markdown."
                        ),
                    },
                    {
                        "role": "user",
                        "content": (
                            f"Génère un rapport de mission de détection navale satellite "
                            f"daté du {now}.\n\n"
                            f"Résumé des détections :\n{summary_json}\n\n"
                            f"Le rapport doit inclure :\n"
                            f"1. Synthèse opérationnelle\n"
                            f"2. Répartition des détections par type et par zone\n"
                            f"3. Zones à surveiller (basé sur le risk_level)\n"
                            f"4. Navires militaires identifiés (détails)\n"
                            f"5. Recommandations\n"
                            f"6. Limites de l'analyse\n"
                        ),
                    },
                ],
                max_tokens=2000,
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"[NavalHunter] Erreur Mistral rapport: {e}")
            return self._generate_fallback_report(detections_summary)

    def analyze_zone_activity(self, zone_name: str, detections: list[dict]) -> str:
        """Analyse l'activité dans une zone spécifique."""
        if not self.available:
            return f"Analyse de {zone_name}: {len(detections)} détections."

        det_summary = json.dumps(detections[:10], ensure_ascii=False, indent=2)

        try:
            response = self.client.chat.complete(
                model=MISTRAL_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Tu es un analyste géostratégique naval. "
                            "Analyse les activités navales détectées et fournis "
                            "une évaluation de la situation. Réponds en français."
                        ),
                    },
                    {
                        "role": "user",
                        "content": (
                            f"Zone : {zone_name}\n"
                            f"Nombre de détections : {len(detections)}\n"
                            f"Détails (max 10) :\n{det_summary}\n\n"
                            f"Fournis une analyse courte de l'activité navale dans cette zone."
                        ),
                    },
                ],
                max_tokens=500,
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"Erreur analyse zone {zone_name}: {e}"

    # ================================================================
    # Fallbacks (quand Mistral n'est pas dispo)
    # ================================================================

    def _fallback_analysis(self, context: dict = None) -> str:
        """Analyse basique sans API."""
        if context:
            zone = context.get("zone_name", "zone inconnue")
            risk = context.get("risk_level", "inconnu")
            return (
                f"🔍 Navire détecté dans la zone {zone} "
                f"(niveau de risque: {risk}). "
                f"Analyse détaillée indisponible (API Mistral non connectée)."
            )
        return "🔍 Navire détecté. Analyse détaillée indisponible."

    def _generate_fallback_report(self, summary: dict) -> str:
        """Rapport basique sans API."""
        now = datetime.now().strftime("%d/%m/%Y à %H:%M")
        total = summary.get("total_detections", 0)
        military = summary.get("military_count", 0)
        civil = summary.get("civil_count", 0)

        return f"""# 📋 Rapport de Mission NavalHunter
## Date : {now}

### Synthèse
- **Détections totales** : {total}
- **Navires militaires** : {military}
- **Navires civils** : {civil}
- **Confiance moyenne** : {summary.get('avg_confidence', 'N/A')}

### Répartition par catégorie
{json.dumps(summary.get('by_category', {}), ensure_ascii=False, indent=2)}

### Répartition par zone
{json.dumps(summary.get('by_zone', {}), ensure_ascii=False, indent=2)}

> ⚠️ Rapport généré localement (API Mistral non connectée).
> Pour un rapport enrichi, configurez la clé API dans .env
"""


# Instance singleton
mistral_analyzer = MistralAnalyzer()
