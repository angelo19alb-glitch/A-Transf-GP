"""
NavalHunter — Détecteur de navires (YOLOv8)
Utilise un modèle YOLOv8 pré-entraîné pour détecter les navires sur images satellites.
"""
import io
import base64
from pathlib import Path
from typing import Optional

import numpy as np
from PIL import Image

from backend.config import (
    YOLO_MODEL_NAME,
    YOLO_CONFIDENCE_THRESHOLD,
    YOLO_IOU_THRESHOLD,
    MODELS_DIR,
)


class ShipDetector:
    """Wrapper YOLOv8 pour la détection de navires."""

    def __init__(self):
        self._model = None

    @property
    def model(self):
        """Chargement paresseux du modèle YOLOv8."""
        if self._model is None:
            try:
                from ultralytics import YOLO

                # Vérifier si un modèle fine-tuné existe
                finetuned_path = MODELS_DIR / "best.pt"
                if finetuned_path.exists():
                    print(f"[NavalHunter] Chargement du modèle fine-tuné: {finetuned_path}")
                    self._model = YOLO(str(finetuned_path))
                else:
                    print(f"[NavalHunter] Chargement du modèle pré-entraîné: {YOLO_MODEL_NAME}")
                    self._model = YOLO(YOLO_MODEL_NAME)
            except ImportError:
                print("[NavalHunter] ERREUR: ultralytics non installé. pip install ultralytics")
                raise
        return self._model

    def detect(
        self,
        image_source,
        confidence: float = YOLO_CONFIDENCE_THRESHOLD,
        iou: float = YOLO_IOU_THRESHOLD,
    ) -> list[dict]:
        """
        Détecte les navires dans une image.

        Args:
            image_source: Chemin vers l'image, objet PIL Image, ou bytes
            confidence: Seuil de confiance minimum
            iou: Seuil IoU pour la suppression des doublons

        Returns:
            Liste de détections avec bbox, confiance, classe
        """
        # Convertir bytes en PIL Image si nécessaire
        if isinstance(image_source, bytes):
            image_source = Image.open(io.BytesIO(image_source))

        # Lancer l'inférence
        results = self.model(
            image_source,
            conf=confidence,
            iou=iou,
            verbose=False,
        )

        detections = []
        for result in results:
            if result.boxes is None:
                continue

            img_h, img_w = result.orig_shape

            for box in result.boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                conf = float(box.conf[0])
                cls_id = int(box.cls[0])
                cls_name = result.names.get(cls_id, f"class_{cls_id}")

                # On garde uniquement les bateaux (classe "boat" dans COCO)
                # mais on accepte aussi d'autres véhicules maritimes
                boat_classes = {"boat", "ship"}
                if cls_name.lower() not in boat_classes and cls_id != 8:
                    continue

                cx = (x1 + x2) / 2
                cy = (y1 + y2) / 2
                if cx < img_w / 2:
                    quadrant = "Haut-Gauche" if cy < img_h / 2 else "Bas-Gauche"
                else:
                    quadrant = "Haut-Droit" if cy < img_h / 2 else "Bas-Droit"

                detections.append({
                    "bbox": {
                        "x1": round(x1, 2),
                        "y1": round(y1, 2),
                        "x2": round(x2, 2),
                        "y2": round(y2, 2),
                    },
                    "bbox_normalized": {
                        "x": round(x1 / img_w, 6),
                        "y": round(y1 / img_h, 6),
                        "w": round((x2 - x1) / img_w, 6),
                        "h": round((y2 - y1) / img_h, 6),
                    },
                    "confidence": round(conf, 4),
                    "class_id": cls_id,
                    "class_name": cls_name,
                    "area_px": round((x2 - x1) * (y2 - y1), 2),
                    "area_pct": round(
                        ((x2 - x1) * (y2 - y1)) / (img_w * img_h) * 100, 4
                    ),
                    "aspect_ratio": round((x2 - x1) / max(y2 - y1, 1), 4),
                    "quadrant": quadrant,
                })

        return detections

    def detect_and_crop(
        self,
        image_source,
        confidence: float = YOLO_CONFIDENCE_THRESHOLD,
        padding: int = 10,
    ) -> list[dict]:
        """
        Détecte les navires et retourne les crops en base64.

        Returns:
            Liste de détections avec le champ 'crop_b64' ajouté
        """
        if isinstance(image_source, bytes):
            pil_img = Image.open(io.BytesIO(image_source))
        elif isinstance(image_source, (str, Path)):
            pil_img = Image.open(image_source)
        else:
            pil_img = image_source

        detections = self.detect(pil_img, confidence=confidence)

        for det in detections:
            bbox = det["bbox"]
            # Crop avec padding
            left = max(0, int(bbox["x1"]) - padding)
            top = max(0, int(bbox["y1"]) - padding)
            right = min(pil_img.width, int(bbox["x2"]) + padding)
            bottom = min(pil_img.height, int(bbox["y2"]) + padding)

            crop = pil_img.crop((left, top, right, bottom))

            # Convertir en base64
            buf = io.BytesIO()
            crop.save(buf, format="PNG")
            det["crop_b64"] = base64.b64encode(buf.getvalue()).decode("utf-8")

        return detections

    def detect_all_objects(
        self,
        image_source,
        confidence: float = 0.15,
    ) -> list[dict]:
        """
        Détecte TOUS les objets (pas seulement les bateaux).
        Utile pour l'exploration et le debug.
        """
        if isinstance(image_source, bytes):
            image_source = Image.open(io.BytesIO(image_source))

        results = self.model(image_source, conf=confidence, verbose=False)
        detections = []

        for result in results:
            if result.boxes is None:
                continue

            for box in result.boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                conf = float(box.conf[0])
                cls_id = int(box.cls[0])
                cls_name = result.names.get(cls_id, f"class_{cls_id}")

                detections.append({
                    "bbox": [round(x1, 2), round(y1, 2), round(x2, 2), round(y2, 2)],
                    "confidence": round(conf, 4),
                    "class_id": cls_id,
                    "class_name": cls_name,
                })

        return detections


# Instance singleton
ship_detector = ShipDetector()
