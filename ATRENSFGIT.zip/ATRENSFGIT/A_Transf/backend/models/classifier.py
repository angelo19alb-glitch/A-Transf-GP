"""
NavalHunter — Classifieur de navires (civil / militaire + type)
Utilise les features extraites des détections pour classifier les navires.
"""
import json
import pickle
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from backend.config import SHIP_CATEGORIES, MILITARY_TYPES, MODELS_DIR


class ShipClassifier:
    """
    Classifie les navires détectés :
    - Classification binaire : civil vs militaire
    - Classification multi-classes : type exact de navire

    Utilise un Random Forest entraîné sur les features des annotations hackathon.
    """

    def __init__(self):
        self._binary_model = None
        self._multi_model = None
        self._is_trained = False

    def _extract_features(self, detection: dict) -> np.ndarray:
        """
        Extrait des features à partir d'une détection.
        Features : area_pct, aspect_ratio, bbox_w_norm, bbox_h_norm, confidence
        """
        if "bbox_normalized" in detection:
            w = detection["bbox_normalized"].get("w", 0.1)
            h = detection["bbox_normalized"].get("h", 0.1)
        elif "bbox" in detection and isinstance(detection["bbox"], dict):
            # Calculer à partir des coordonnées absolues (on normalise sur 1)
            bbox = detection["bbox"]
            w = (bbox["x2"] - bbox["x1"]) / 1000  # approximation
            h = (bbox["y2"] - bbox["y1"]) / 1000
        else:
            w, h = 0.1, 0.1

        area_pct = detection.get("area_pct", w * h * 100)
        aspect_ratio = detection.get("aspect_ratio", w / max(h, 0.001))
        confidence = detection.get("confidence", 0.5)

        return np.array([area_pct, aspect_ratio, w, h, confidence])

    def train_from_hackathon_data(self, detections_csv_path: str) -> dict:
        """
        Entraîne les classifieurs à partir des données de détection du hackathon.
        Utilise detection_results.csv qui contient is_military et category.
        """
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.svm import SVC
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import classification_report, accuracy_score

        df = pd.read_csv(detections_csv_path)

        # Extraire les features des bounding boxes
        features = []
        for _, row in df.iterrows():
            bbox_parts = str(row["bbox"]).split(",")
            if len(bbox_parts) >= 4:
                x, y, w, h = [float(v) for v in bbox_parts[:4]]
            else:
                x, y, w, h = 0.5, 0.5, 0.1, 0.1

            area = w * h
            aspect_ratio = w / max(h, 0.001)
            confidence = float(row.get("confidence", 0.5))
            features.append([area * 100, aspect_ratio, w, h, confidence])

        X = np.array(features)

        # ── Classification binaire (civil/militaire) ──
        y_binary = df["is_military"].astype(int).values
        X_train, X_test, y_train, y_test = train_test_split(
            X, y_binary, test_size=0.2, random_state=42, stratify=y_binary
        )

        self._binary_model = RandomForestClassifier(
            n_estimators=100, random_state=42, class_weight="balanced"
        )
        self._binary_model.fit(X_train, y_train)
        y_pred = self._binary_model.predict(X_test)
        binary_accuracy = accuracy_score(y_test, y_pred)
        binary_report = classification_report(
            y_test, y_pred, target_names=["Civil", "Militaire"], output_dict=True
        )

        # ── Classification multi-classes (type exact) ──
        category_names = df["category"].unique().tolist()
        category_to_id = {name: i for i, name in enumerate(category_names)}
        y_multi = df["category"].map(category_to_id).values

        X_train_m, X_test_m, y_train_m, y_test_m = train_test_split(
            X, y_multi, test_size=0.2, random_state=42
        )

        self._multi_model = RandomForestClassifier(
            n_estimators=150, random_state=42, class_weight="balanced"
        )
        self._multi_model.fit(X_train_m, y_train_m)
        y_pred_m = self._multi_model.predict(X_test_m)
        multi_accuracy = accuracy_score(y_test_m, y_pred_m)

        # Sauvegarder les mappings
        self._category_names = category_names
        self._category_to_id = category_to_id
        self._id_to_category = {v: k for k, v in category_to_id.items()}
        self._is_trained = True

        # Sauvegarder les modèles
        self._save_models()

        return {
            "binary": {
                "accuracy": round(binary_accuracy, 4),
                "report": binary_report,
            },
            "multi_class": {
                "accuracy": round(multi_accuracy, 4),
                "num_classes": len(category_names),
                "classes": category_names,
            },
        }

    def _save_models(self):
        """Sauvegarde les modèles entraînés."""
        models_data = {
            "binary_model": self._binary_model,
            "multi_model": self._multi_model,
            "category_names": self._category_names,
            "category_to_id": self._category_to_id,
            "id_to_category": self._id_to_category,
        }
        save_path = MODELS_DIR / "classifier_models.pkl"
        with open(save_path, "wb") as f:
            pickle.dump(models_data, f)
        print(f"[NavalHunter] Modèles de classification sauvegardés: {save_path}")

    def _load_models(self) -> bool:
        """Charge les modèles sauvegardés."""
        load_path = MODELS_DIR / "classifier_models.pkl"
        if not load_path.exists():
            return False
        try:
            with open(load_path, "rb") as f:
                data = pickle.load(f)
            self._binary_model = data["binary_model"]
            self._multi_model = data["multi_model"]
            self._category_names = data["category_names"]
            self._category_to_id = data["category_to_id"]
            self._id_to_category = data["id_to_category"]
            self._is_trained = True
            print(f"[NavalHunter] Modèles de classification chargés depuis: {load_path}")
            return True
        except Exception as e:
            print(f"[NavalHunter] Erreur chargement modèles: {e}")
            return False

    def classify(self, detection: dict) -> dict:
        """
        Classifie un navire détecté.

        Returns:
            dict avec is_military, military_proba, ship_type, type_proba
        """
        # Essayer de charger les modèles si pas encore fait
        if not self._is_trained:
            self._load_models()

        if not self._is_trained:
            # Fallback : classification basique sur les features
            return self._classify_heuristic(detection)

        features = self._extract_features(detection).reshape(1, -1)

        # Binaire
        is_military = bool(self._binary_model.predict(features)[0])
        military_proba = float(
            self._binary_model.predict_proba(features)[0][1]
        )

        # Multi-classes
        type_id = int(self._multi_model.predict(features)[0])
        ship_type = self._id_to_category.get(type_id, "Inconnu")
        type_proba = float(
            self._multi_model.predict_proba(features)[0][type_id]
        )

        return {
            "is_military": is_military,
            "military_probability": round(military_proba, 4),
            "ship_type": ship_type,
            "type_probability": round(type_proba, 4),
        }

    def _classify_heuristic(self, detection: dict) -> dict:
        """
        Classification heuristique de fallback quand les modèles
        ne sont pas encore entraînés.
        Basée sur la taille et le ratio des bounding boxes.
        """
        area = detection.get("area_pct", 1.0)
        ratio = detection.get("aspect_ratio", 1.0)

        # Heuristique simple :
        # - Les navires militaires sont généralement plus longs et fins
        # - Les porte-avions sont très grands
        # - Les cargos sont massifs mais plus trapus
        is_military = ratio > 2.5 or area > 3.0
        military_proba = min(0.5 + (ratio - 1.5) * 0.1 + (area - 1.0) * 0.05, 0.95)
        military_proba = max(military_proba, 0.05)

        if area > 5.0 and ratio > 3.0:
            ship_type = "Porte-avions"
        elif ratio > 3.5:
            ship_type = "Destroyer"
        elif ratio > 2.5:
            ship_type = "Frégate"
        elif area > 3.0:
            ship_type = "Cargo"
        elif area < 0.5:
            ship_type = "Chalutier"
        else:
            ship_type = "Navire civil"

        return {
            "is_military": is_military,
            "military_probability": round(military_proba, 4),
            "ship_type": ship_type,
            "type_probability": 0.5,  # Faible confiance (heuristique)
        }

    def classify_batch(self, detections: list[dict]) -> list[dict]:
        """Classifie un lot de détections."""
        results = []
        for det in detections:
            classification = self.classify(det)
            results.append({**det, **classification})
        return results


# Instance singleton
ship_classifier = ShipClassifier()
